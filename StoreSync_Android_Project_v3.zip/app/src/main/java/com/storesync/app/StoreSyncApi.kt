package com.storesync.app

import android.content.Context
import android.net.Uri
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.UUID
import java.util.concurrent.TimeUnit

 data class StoreInfo(val id: String, val name: String, val role: String)
 data class ProductInfo(val id: String, val storeId: String, val name: String, val price: Double, val imagePath: String? = null)
 data class NoteInfo(val id: String, val note: String, val createdAt: String, val read: Boolean)

class StoreSyncApi(context: Context) {
    private val prefs = context.getSharedPreferences("storesync_session", Context.MODE_PRIVATE)
    private val client = OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
    private val base get() = AppConfig.SUPABASE_URL.trimEnd('/')
    private val key get() = AppConfig.SUPABASE_PUBLISHABLE_KEY
    private var access: String? get() = prefs.getString("access", null); set(v) { prefs.edit().putString("access", v).apply() }
    private var refresh: String? get() = prefs.getString("refresh", null); set(v) { prefs.edit().putString("refresh", v).apply() }
    var userId: String? get() = prefs.getString("user_id", null); private set(v) { prefs.edit().putString("user_id", v).apply() }
    var email: String? get() = prefs.getString("email", null); private set(v) { prefs.edit().putString("email", v).apply() }
    val signedIn: Boolean get() = !access.isNullOrBlank() && !userId.isNullOrBlank()

    private fun request(method: String, path: String, body: String? = null, auth: Boolean = true, extraHeaders: Map<String,String> = emptyMap(), allowRefresh: Boolean = true): String {
        if (key.startsWith("PASTE_")) throw IOException("Setup needed: add your Supabase publishable key in AppConfig.kt, then rebuild the APK.")
        val builder = Request.Builder().url("$base$path").header("apikey", key).header("Accept", "application/json")
        if (auth) builder.header("Authorization", "Bearer ${access ?: key}") else builder.header("Authorization", "Bearer $key")
        extraHeaders.forEach { (k,v) -> builder.header(k,v) }
        val media = "application/json; charset=utf-8".toMediaType()
        when(method) {
            "GET" -> builder.get()
            "POST" -> builder.post((body ?: "{}").toRequestBody(media))
            "PATCH" -> builder.patch((body ?: "{}").toRequestBody(media))
            "DELETE" -> builder.delete((body ?: "").toRequestBody(media))
            else -> throw IOException("Unsupported request")
        }
        client.newCall(builder.build()).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (response.code == 401 && auth && allowRefresh && !refresh.isNullOrBlank()) {
                refreshSession()
                return request(method, path, body, auth, extraHeaders, allowRefresh = false)
            }
            if (!response.isSuccessful) {
                val detail = try { JSONObject(text).optString("message", JSONObject(text).optString("msg", text)) } catch (_: Exception) { text }
                throw IOException("Server ${response.code}: $detail")
            }
            return text
        }
    }
    private fun refreshSession() {
        val token = refresh ?: throw IOException("Session expired. Please sign in again.")
        val o = authRequest("/auth/v1/token?grant_type=refresh_token", JSONObject().put("refresh_token", token))
        saveSession(o)
    }
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun authRequest(path: String, json: JSONObject): JSONObject {
        val req = Request.Builder().url("$base$path").header("apikey", key).header("Content-Type", "application/json").post(json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())).build()
        client.newCall(req).execute().use { r -> val text=r.body?.string().orEmpty(); if(!r.isSuccessful) throw IOException(try{JSONObject(text).optString("msg", JSONObject(text).optString("message", text))}catch(_:Exception){text}); return JSONObject(text) }
    }
    private fun saveSession(o: JSONObject) {
        access = o.optString("access_token").takeIf { it.isNotBlank() && it != "null" }
        refresh = o.optString("refresh_token").takeIf { it.isNotBlank() && it != "null" }
        val u = o.optJSONObject("user")
        userId = u?.optString("id")?.takeIf { !it.isNullOrBlank() && it != "null" } ?: userId
        email = u?.optString("email")?.takeIf { !it.isNullOrBlank() && it != "null" } ?: email
    }
    fun signUp(emailValue: String, password: String) { val o=authRequest("/auth/v1/signup?redirect_to=${enc(AppConfig.AUTH_REDIRECT_URL)}", JSONObject().put("email",emailValue).put("password",password)); if(o.has("access_token")) saveSession(o) else throw IOException("Account created. Check your email and tap the confirmation link. It should return to StoreSync; then sign in.") }
    fun signIn(emailValue: String, password: String) { val o=authRequest("/auth/v1/token?grant_type=password", JSONObject().put("email",emailValue).put("password",password)); saveSession(o); if(!signedIn) throw IOException("Sign-in did not return a session. Check email confirmation settings.") }
    fun verifyPassword(password: String) { val e=email ?: throw IOException("Please sign in again."); authRequest("/auth/v1/token?grant_type=password", JSONObject().put("email",e).put("password",password)) }
    fun signOut() { try { request("POST", "/auth/v1/logout", "{}") } catch (_: Exception) {}; prefs.edit().clear().apply() }

    fun myStores(): List<StoreInfo> {
        val uid=userId ?: return emptyList()
        val memberships=JSONArray(request("GET","/rest/v1/store_members?select=store_id,role&user_id=eq.${enc(uid)}"))
        val result=mutableListOf<StoreInfo>()
        for(i in 0 until memberships.length()) { val m=memberships.getJSONObject(i); val id=m.getString("store_id"); val a=JSONArray(request("GET","/rest/v1/stores?select=id,name&id=eq.${enc(id)}")); if(a.length()>0) result.add(StoreInfo(id,a.getJSONObject(0).optString("name","Store"),m.optString("role","salesperson"))) }
        return result
    }
    fun createStore(name: String) { val uid=userId ?: throw IOException("Sign in first"); request("POST","/rest/v1/stores",JSONObject().put("name",name).put("created_by",uid).toString(), extraHeaders=mapOf("Prefer" to "return=representation")) }
    fun joinStore(code: String) { request("POST","/rest/v1/rpc/join_store_with_code",JSONObject().put("p_invite_code",code.trim()).toString()) }
    fun createInvite(storeId: String): String { val code=UUID.randomUUID().toString().replace("-", "").take(10).uppercase(); request("POST","/rest/v1/store_invites",JSONObject().put("store_id",storeId).put("code",code).put("created_by",userId).toString(), extraHeaders=mapOf("Prefer" to "return=minimal")); return code }

    fun products(storeId: String): List<ProductInfo> {
        val a=JSONArray(request("GET","/rest/v1/products?select=id,store_id,name,price,image_url&store_id=eq.${enc(storeId)}&order=name.asc"))
        return (0 until a.length()).map { i -> val p=a.getJSONObject(i); ProductInfo(p.getString("id"),p.getString("store_id"),p.optString("name"),p.optDouble("price"),p.optString("image_url").takeIf{it.isNotBlank()&&it!="null"}) }
    }
    fun addProduct(storeId: String, name: String, price: Double, imageUri: Uri?, context: Context) {
        var path: String?=null
        if(imageUri!=null) {
            val bytes=context.contentResolver.openInputStream(imageUri)?.use { it.readBytes() } ?: throw IOException("Could not read selected image")
            path="$storeId/${UUID.randomUUID()}.jpg"
            val req=Request.Builder().url("$base/storage/v1/object/${AppConfig.STORAGE_BUCKET}/$path").header("apikey",key).header("Authorization","Bearer ${access ?: key}").header("Content-Type","image/jpeg").post(bytes.toRequestBody("image/jpeg".toMediaType())).build()
            client.newCall(req).execute().use { if(!it.isSuccessful) throw IOException("Photo upload failed (${it.code}): ${it.body?.string().orEmpty()}") }
        }
        val obj=JSONObject().put("store_id",storeId).put("name",name).put("price",price).put("updated_by",userId)
        if(path!=null) obj.put("image_url",path)
        request("POST","/rest/v1/products",obj.toString(),extraHeaders=mapOf("Prefer" to "return=minimal"))
    }
    fun updatePrice(productId: String, price: Double) { request("PATCH","/rest/v1/products?id=eq.${enc(productId)}",JSONObject().put("price",price).put("updated_by",userId).toString(),extraHeaders=mapOf("Prefer" to "return=minimal")) }
    fun sendNote(storeId: String, note: String) { request("POST","/rest/v1/salesperson_notes",JSONObject().put("store_id",storeId).put("salesperson_id",userId).put("note",note).toString(),extraHeaders=mapOf("Prefer" to "return=minimal")) }
    fun notes(storeId: String): List<NoteInfo> { val a=JSONArray(request("GET","/rest/v1/salesperson_notes?select=id,note,created_at,is_read&store_id=eq.${enc(storeId)}&order=created_at.desc")); return (0 until a.length()).map { val n=a.getJSONObject(it); NoteInfo(n.getString("id"),n.optString("note"),n.optString("created_at"),n.optBoolean("is_read")) } }
    fun cacheStores(context: Context, stores: List<StoreInfo>) {
        val a=JSONArray(); stores.forEach { a.put(JSONObject().put("id",it.id).put("name",it.name).put("role",it.role)) }
        context.getSharedPreferences("storesync_cache",Context.MODE_PRIVATE).edit().putString("stores",a.toString()).apply()
    }
    fun cachedStores(context: Context): List<StoreInfo> {
        val a=try { JSONArray(context.getSharedPreferences("storesync_cache",Context.MODE_PRIVATE).getString("stores","[]")) } catch (_:Exception) { JSONArray() }
        return (0 until a.length()).map { val o=a.getJSONObject(it); StoreInfo(o.getString("id"),o.optString("name"),o.optString("role","salesperson")) }
    }
    fun cachedProducts(context: Context, storeId: String): List<ProductInfo> { val p=context.getSharedPreferences("storesync_cache",Context.MODE_PRIVATE); val a=try{JSONArray(p.getString("products_$storeId","[]"))}catch(_:Exception){JSONArray()}; return (0 until a.length()).map{val o=a.getJSONObject(it);ProductInfo(o.getString("id"),o.getString("store_id"),o.optString("name"),o.optDouble("price"),o.optString("image_path").takeIf{s->s.isNotBlank()&&s!="null"})} }
    fun cacheProducts(context: Context, storeId: String, products: List<ProductInfo>) { val a=JSONArray(); products.forEach{a.put(JSONObject().put("id",it.id).put("store_id",it.storeId).put("name",it.name).put("price",it.price).put("image_path",it.imagePath))}; context.getSharedPreferences("storesync_cache",Context.MODE_PRIVATE).edit().putString("products_$storeId",a.toString()).apply() }
}
