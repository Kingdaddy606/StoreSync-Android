package com.storesync.app

import android.content.Context
import android.net.Uri
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.UUID

data class ProductInfo(val id: String, val name: String, val price: Double, val imageUrl: String? = null)

class StoreSyncApi(private val context: Context) {
    private val prefs = context.getSharedPreferences("storesync_catalogue", Context.MODE_PRIVATE)
    private val client = OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
    private val base get() = AppConfig.SUPABASE_URL.trimEnd('/')
    private val key get() = AppConfig.SUPABASE_PUBLISHABLE_KEY
    private fun request(method: String, path: String, body: String? = null): String {
        if (key.startsWith("PASTE_")) throw IOException("Setup needed: add your Supabase publishable key in GitHub Actions secrets.")
        val b = Request.Builder().url("$base$path").header("apikey", key).header("Authorization", "Bearer $key").header("Accept", "application/json")
        when (method) {
            "GET" -> b.get()
            else -> b.post((body ?: "{}").toRequestBody("application/json; charset=utf-8".toMediaType()))
        }
        client.newCall(b.build()).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (!r.isSuccessful) {
                val detail = try { JSONObject(text).optString("message", JSONObject(text).optString("details", text)) } catch (_: Exception) { text }
                throw IOException("Server ${r.code}: $detail")
            }
            return text
        }
    }
    private fun rpc(name: String, args: JSONObject): String = request("POST", "/rest/v1/rpc/$name", args.toString())

    fun uploadProductPhoto(uri: Uri, managementPassword: String): String {
        if (!verifyPassword(managementPassword)) throw IOException("Incorrect management password.")
        val resolver = context.contentResolver
        val mime = resolver.getType(uri) ?: "image/jpeg"
        if (!mime.startsWith("image/")) throw IOException("Please choose an image file.")
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IOException("Could not read the selected photo.")
        if (bytes.size > 5 * 1024 * 1024) throw IOException("Photo must be 5 MB or smaller.")
        val ext = when (mime.lowercase()) {
            "image/png" -> "png"
            "image/webp" -> "webp"
            "image/heic" -> "heic"
            else -> "jpg"
        }
        val objectName = "catalogue/${UUID.randomUUID()}.$ext"
        val encoded = objectName.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
        val req = Request.Builder()
            .url("$base/storage/v1/object/product-images/$encoded")
            .header("apikey", key)
            .header("Authorization", "Bearer $key")
            .header("Content-Type", mime)
            .header("x-upsert", "false")
            .post(bytes.toRequestBody(mime.toMediaType()))
            .build()
        client.newCall(req).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("Photo upload failed (${response.code}): $body")
        }
        return "$base/storage/v1/object/public/product-images/$encoded"
    }

    fun products(): List<ProductInfo> {
        val a = JSONArray(request("GET", "/rest/v1/shared_catalogue_products?select=id,name,price,image_url&order=name.asc"))
        return (0 until a.length()).map { i -> val o=a.getJSONObject(i); ProductInfo(o.getString("id"),o.optString("name"),o.optDouble("price"),o.optString("image_url").takeIf { it.isNotBlank() && it != "null" }) }
    }
    fun cachedProducts(): List<ProductInfo> {
        val a = try { JSONArray(prefs.getString("products", "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until a.length()).map { i -> val o=a.getJSONObject(i); ProductInfo(o.getString("id"),o.optString("name"),o.optDouble("price"),o.optString("image_url").takeIf { it.isNotBlank() && it != "null" }) }
    }
    fun cacheProducts(list: List<ProductInfo>) {
        val a=JSONArray(); list.forEach { a.put(JSONObject().put("id",it.id).put("name",it.name).put("price",it.price).put("image_url",it.imageUrl)) }
        prefs.edit().putString("products",a.toString()).apply()
    }
    fun hasPassword(): Boolean = rpc("management_password_is_set", JSONObject()).trim().equals("true", true)
    fun initializePassword(newPassword: String) { rpc("initialize_management_password", JSONObject().put("p_new_password",newPassword)) }
    fun verifyPassword(password: String): Boolean = rpc("verify_management_password", JSONObject().put("p_password",password)).trim().equals("true", true)
    fun changePassword(current: String, next: String) { rpc("change_management_password", JSONObject().put("p_current_password",current).put("p_new_password",next)) }
    fun addProduct(password: String, name: String, price: Double, imageUrl: String?) {
        rpc("management_add_product", JSONObject().put("p_password",password).put("p_name",name).put("p_price",price).put("p_image_url",imageUrl))
    }
    fun updateProduct(password: String, id: String, name: String, price: Double, imageUrl: String?) {
        rpc("management_update_product", JSONObject().put("p_password",password).put("p_product_id",id).put("p_name",name).put("p_price",price).put("p_image_url",imageUrl))
    }
    fun deleteProduct(password: String, id: String) { rpc("management_delete_product", JSONObject().put("p_password",password).put("p_product_id",id)) }
}
