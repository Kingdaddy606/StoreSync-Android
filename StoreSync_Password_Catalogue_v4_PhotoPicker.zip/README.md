# StoreSync v4 — Password-protected shared catalogue

This is a simplified Android catalogue project. It removes the old email sign-in, store membership, salesperson, invitation and note flows.

## User experience
- Catalogue browsing and search do not require sign-in or a password.
- Scroll mode shows a normal product list.
- Swipe mode shows one product at a time; swipe horizontally or use Previous/Next.
- Management mode is unlocked with one shared password.
- Management mode supports adding, editing and deleting products, plus changing the shared password.
- Product names and prices are cached locally for offline viewing. Changes and refresh require internet.

## Important setup — run the SQL migration first
1. Open the StoreSync Supabase project SQL Editor.
2. Run `backend/03_password_catalogue.sql` in full.
3. Run `backend/04_product_photo_picker.sql` in full.
3. This creates a separate `shared_catalogue_products` table and copies existing rows from the old `products` table when present. It does not delete the old `stores`, `store_members`, `products`, or `salesperson_notes` data. The old tables are no longer used by this app.
4. Install the new APK and tap **Manage**. The first person to do so creates the shared password. Choose a strong password of at least 8 characters and keep it private.

## Product photo selection
- The product editor has a **Choose product photo** button using Android's photo picker. No photo URL needs to be typed.
- Selected images are uploaded to the `product-images` Supabase Storage bucket (maximum 5 MB; JPEG, PNG, WebP, HEIC).
- Run `backend/04_product_photo_picker.sql` after `backend/03_password_catalogue.sql`.
- The migration makes the bucket publicly readable and permits anonymous image uploads. Anyone can upload an image file to the bucket, but product catalogue rows can only be changed through the password-checked database functions. Avoid storing sensitive images in this bucket.

## GitHub Actions
- Keep the repository secret `SUPABASE_PUBLISHABLE_KEY` (the `sb_publishable_...` key).
- Upload `StoreSync_Password_Catalogue_v4.zip` to the repository root.
- Use the workflow in `GITHUB_ACTIONS_WORKFLOW.txt` in `.github/workflows/build.yml`.
- Run the workflow and download the artifact `StoreSync-v4-password-catalogue-APK`.

Never put a Supabase service-role or secret key in the APK.

## Current limitations and security notes
- This photo-upload implementation uses public bucket upload access so a login-free app can upload selected images. Uploading is restricted by bucket MIME types and a 5 MB limit, but it is not strongly rate-limited; monitor Storage usage.
- The shared management password is verified by Supabase database functions and stored as a bcrypt hash, not as plaintext. However, a public anonymous app cannot provide strong per-person accountability or eliminate online password-guessing attempts without adding server-side rate limiting. Use a long, unique password and do not publish it.
- The first user to initialize the password claims the catalogue. Run the migration and initialize it yourself before sharing the APK.
- This source has not yet been built or tested against the live Supabase project in this environment. Run GitHub Actions and test the migration before relying on it.
