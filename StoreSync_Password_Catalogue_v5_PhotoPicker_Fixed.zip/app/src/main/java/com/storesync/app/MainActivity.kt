package com.storesync.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); val api=StoreSyncApi(this); setContent { MaterialTheme(colorScheme=lightColorScheme(primary=androidx.compose.ui.graphics.Color(0xFF176B4D))) { StoreSyncScreen(api) } } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StoreSyncScreen(api: StoreSyncApi) {
    val scope= rememberCoroutineScope()
    var products by remember { mutableStateOf(emptyList<ProductInfo>()) }
    var search by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Loading catalogue…") }
    var management by remember { mutableStateOf(false) }
    var password by remember { mutableStateOf("") }
    var currentPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordSet by remember { mutableStateOf<Boolean?>(null) }
    var setupMode by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf("Scroll") }
    var editProduct by remember { mutableStateOf<ProductInfo?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var imageUrl by remember { mutableStateOf("") }
    var swipeIndex by remember { mutableIntStateOf(0) }
    var showAccessDialog by remember { mutableStateOf(false) }
    var showPasswordChange by remember { mutableStateOf(false) }

    fun runTask(success: String, task: suspend () -> Unit) {
        scope.launch { busy=true; message=""; try { task(); message=success } catch(e:Exception) { message=e.message ?: "Something went wrong." } finally { busy=false } }
    }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            runTask("Photo uploaded.") {
                val uploaded = withContext(Dispatchers.IO) { api.uploadProductPhoto(uri, password) }
                imageUrl = uploaded
            }
        }
    }
    fun refresh() = runTask("Catalogue refreshed.") { products=withContext(Dispatchers.IO){api.products()}; withContext(Dispatchers.IO){api.cacheProducts(products)}; passwordSet=withContext(Dispatchers.IO){api.hasPassword()} }
    LaunchedEffect(Unit) {
        products=api.cachedProducts()
        try { products=withContext(Dispatchers.IO){api.products()}; api.cacheProducts(products); passwordSet=withContext(Dispatchers.IO){api.hasPassword()}; message="" }
        catch(e:Exception) { message=if(products.isNotEmpty()) "Offline mode — showing saved prices." else (e.message ?: "Could not load catalogue.") }
    }
    val visible=products.filter { it.name.contains(search,true) }
    fun startEdit(p: ProductInfo?) { editProduct=p; name=p?.name.orEmpty(); price=p?.price?.toString().orEmpty(); imageUrl=p?.imageUrl.orEmpty(); showEditor=true }
    Scaffold(topBar={ TopAppBar(title={Text("StoreSync")}, actions={ IconButton(onClick={refresh()},enabled=!busy){Icon(Icons.Default.Refresh,"Refresh catalogue")} }) }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(horizontal=16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            if(message.isNotBlank()) Text(message,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.secondary)
            if(busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            OutlinedTextField(search,{search=it},Modifier.fillMaxWidth(),label={Text("Search products")},singleLine=true,leadingIcon={Icon(Icons.Default.Search,null)})
            Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("${visible.size} products",Modifier.weight(1f),style=MaterialTheme.typography.labelLarge)
                TextButton(onClick={mode="Scroll"}){Text("Scroll")}
                TextButton(onClick={mode="Swipe"}){Text("Swipe")}
                Button(onClick={management=false;password="";setupMode=false;showAccessDialog=true}) { Text("Manage") }
            }
            if(visible.isEmpty()) {
                Box(Modifier.fillMaxWidth().weight(1f),contentAlignment=Alignment.Center){Text(if(products.isEmpty()) "No products yet. Unlock management to add your first product." else "No matching products.")}
            } else if(mode=="Swipe") {
                val index=swipeIndex.coerceIn(0,visible.lastIndex)
                val p=visible[index]
                Card(Modifier.fillMaxWidth().weight(1f).pointerInput(visible,index){ var delta=0f; detectHorizontalDragGestures(onHorizontalDrag={_,d->delta+=d},onDragEnd={ if(delta < -45) swipeIndex=(index+1).coerceAtMost(visible.lastIndex) else if(delta>45) swipeIndex=(index-1).coerceAtLeast(0); delta=0f }) },shape=RoundedCornerShape(24.dp)) {
                    Column(Modifier.fillMaxSize().padding(22.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally) {
                        Text("${index+1} / ${visible.size}",style=MaterialTheme.typography.labelMedium)
                        if (!p.imageUrl.isNullOrBlank()) {
                            Spacer(Modifier.height(12.dp))
                            AsyncImage(model=p.imageUrl, contentDescription=p.name, modifier=Modifier.fillMaxWidth().height(190.dp))
                        }
                        Spacer(Modifier.height(24.dp))
                        Text(p.name,style=MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(12.dp))
                        Text(naira(p.price),style=MaterialTheme.typography.headlineLarge,color=MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(24.dp))
                        if(management) OutlinedButton(onClick={startEdit(p)}){Icon(Icons.Default.Edit,null);Text(" Edit product")}
                        Text("Swipe left or right to move between products",style=MaterialTheme.typography.bodySmall)
                    }
                }
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){ TextButton(onClick={swipeIndex=(index-1).coerceAtLeast(0)}){Text("Previous")}; TextButton(onClick={swipeIndex=(index+1).coerceAtMost(visible.lastIndex)}){Text("Next")}}
            } else {
                LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    items(visible,key={it.id}) { p -> Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
                        if (!p.imageUrl.isNullOrBlank()) AsyncImage(model=p.imageUrl, contentDescription=p.name, modifier=Modifier.size(64.dp))
                        Column(Modifier.weight(1f).padding(start=10.dp)) { Text(p.name,style=MaterialTheme.typography.titleMedium); Text(naira(p.price),style=MaterialTheme.typography.bodyLarge,color=MaterialTheme.colorScheme.primary) }
                        if(management) IconButton(onClick={startEdit(p)}){Icon(Icons.Default.Edit,"Edit product")}
                    } } }
                }
            }
            if(management) Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Button(onClick={startEdit(null)},enabled=!busy,modifier=Modifier.weight(1f)){Icon(Icons.Default.Add,null);Text(" Add product")}
                OutlinedButton(onClick={showPasswordChange=true},modifier=Modifier.weight(1f)){Icon(Icons.Default.Lock,null);Text(" Password")}
                TextButton(onClick={management=false}){Text("Lock")}
            }
        }
    }

    if(showAccessDialog) AlertDialog(onDismissRequest={showAccessDialog=false},title={Text("Management access")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        when(passwordSet) {
            null -> Text("Checking password setup…")
            false -> { Text("Create the shared management password. Anyone who knows it can manage this catalogue."); OutlinedTextField(newPassword,{newPassword=it},label={Text("Create password")},visualTransformation=PasswordVisualTransformation(),singleLine=true) ; OutlinedTextField(confirmPassword,{confirmPassword=it},label={Text("Confirm password")},visualTransformation=PasswordVisualTransformation(),singleLine=true) }
            true -> { Text("Enter the shared password to add, edit or delete products."); OutlinedTextField(password,{password=it},label={Text("Management password")},visualTransformation=PasswordVisualTransformation(),singleLine=true) }
        }
    }},confirmButton={Button(enabled=!busy && when(passwordSet){false->newPassword.length>=8&&newPassword==confirmPassword;true->password.isNotBlank();else->false},onClick={runTask("Management unlocked."){ withContext(Dispatchers.IO){ if(passwordSet==false) api.initializePassword(newPassword) else if(!api.verifyPassword(password)) throw IllegalArgumentException("Incorrect management password.") }; management=true; showAccessDialog=false; password=if(passwordSet==false)newPassword else password; passwordSet=true; newPassword="";confirmPassword="" }}){Text(if(passwordSet==false)"Create password" else "Unlock")}},dismissButton={TextButton(onClick={showAccessDialog=false}){Text("Cancel")}})

    if(showPasswordChange) AlertDialog(onDismissRequest={showPasswordChange=false},title={Text("Change shared password")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        OutlinedTextField(currentPassword,{currentPassword=it},label={Text("Current password")},visualTransformation=PasswordVisualTransformation())
        OutlinedTextField(newPassword,{newPassword=it},label={Text("New password (8+ characters)")},visualTransformation=PasswordVisualTransformation())
        OutlinedTextField(confirmPassword,{confirmPassword=it},label={Text("Confirm new password")},visualTransformation=PasswordVisualTransformation())
    }},confirmButton={Button(enabled=!busy&&currentPassword.isNotBlank()&&newPassword.length>=8&&newPassword==confirmPassword,onClick={runTask("Shared password changed."){withContext(Dispatchers.IO){api.changePassword(currentPassword,newPassword)};password=newPassword;showPasswordChange=false;currentPassword="";newPassword="";confirmPassword=""}}){Text("Change password")}},dismissButton={TextButton(onClick={showPasswordChange=false}){Text("Cancel")}})

    if(showEditor) AlertDialog(onDismissRequest={showEditor=false},title={Text(if(editProduct==null)"Add product" else "Edit product")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        OutlinedTextField(name,{name=it},label={Text("Product name")},singleLine=true)
        OutlinedTextField(price,{price=it},label={Text("Price (NGN)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
        OutlinedButton(onClick={photoPicker.launch("image/*")}, enabled=!busy) {
            Icon(Icons.Default.AddPhotoAlternate, null)
            Text(if(imageUrl.isBlank()) " Choose product photo" else " Change product photo")
        }
        if (imageUrl.isNotBlank()) Text("Photo selected and uploaded", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.primary)
    }},confirmButton={Button(enabled=!busy&&name.isNotBlank()&&(price.toDoubleOrNull()?:-1.0)>=0,onClick={val p=editProduct;val n=name.trim();val amount=price.toDoubleOrNull()!!;val url=imageUrl.trim().ifBlank{null};runTask("Product saved."){withContext(Dispatchers.IO){if(p==null)api.addProduct(password,n,amount,url) else api.updateProduct(password,p.id,n,amount,url);products=api.products();api.cacheProducts(products)};showEditor=false}}){Text("Save")}},dismissButton={Row{if(editProduct!=null) TextButton(onClick={val p=editProduct!!;runTask("Product deleted."){withContext(Dispatchers.IO){api.deleteProduct(password,p.id);products=api.products();api.cacheProducts(products)};showEditor=false}}){Text("Delete",color=MaterialTheme.colorScheme.error)};TextButton(onClick={showEditor=false}){Text("Cancel")}}})
}

private fun naira(value: Double): String = NumberFormat.getCurrencyInstance(Locale("en","NG")).format(value)
