# StoreSync Android — connected starter project

StoreSync is a native Android app built with Kotlin and Jetpack Compose. This project includes the first connected implementation of the main workflows and a backend migration for salesperson invitations.

## Implemented in source
- Email/password account creation and sign-in using Supabase Auth.
- Persistent local session storage for access/refresh tokens returned by Supabase Auth.
- Multiple store memberships and Admin/Salesperson role display.
- Admin store creation.
- One-time salesperson invitation codes (requires the SQL migration below).
- Product list, search, online refresh, and locally cached product data for offline browsing.
- Admin-only product creation and price updates enforced by Supabase RLS.
- Admin password re-verification before price updates.
- Optional product photo upload to the private `product-images` bucket.
- Salesperson note submission and Admin note viewing.
- Minimalist green/white interface.

## Before building
1. Open `app/src/main/java/com/storesync/app/AppConfig.kt`.
2. Replace `PASTE_YOUR_SB_PUBLISHABLE_KEY_HERE` with your Supabase **publishable** key (the `sb_publishable_...` value). The project URL is already set.
3. Never use a Supabase `service_role` or secret key in an Android app.

## Supabase setup
The original database SQL and private Storage bucket/policies were already created in the Supabase project. Now run `backend/02_store_invites.sql` in Supabase SQL Editor to add the one-time invitation workflow. Make sure the private bucket is named exactly `product-images`.

Recommended Auth setting for first testing: use email/password sign-in. If email confirmation is enabled, a new account must confirm its email before it can sign in. Admin and salesperson users each create their own account; the Admin generates a code and shares it with the salesperson, who redeems it in the app.

## Build on GitHub Actions
Use the workflow in `GITHUB_ACTIONS_WORKFLOW.txt` at the project root. It builds a debug APK and uploads it as an artifact. Download the artifact from the successful Actions run and install the APK on Android.

## Important limitations / testing status
This source has not been built against your live Supabase project in this chat. Build and test it in Actions before relying on it. The app currently caches catalogue records (names/prices/IDs) locally; photos upload to private Storage but photo display/signed-image URLs are not yet implemented. Offline mode is read-only. Product creation, price changes, notes, invitations, and syncing require internet. Supabase Row Level Security remains the authority for permissions; UI role checks are not the security boundary.
