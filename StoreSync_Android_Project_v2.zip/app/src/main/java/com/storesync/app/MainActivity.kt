package com.storesync.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val api = StoreSyncApi(this)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF176B4D), secondary = androidx.compose.ui.graphics.Color(0xFF4C6A5D))) { StoreSyncScreen(api) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StoreSyncScreen(api: StoreSyncApi) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var signedIn by remember { mutableStateOf(api.signedIn) }
    var email by remember { mutableStateOf(api.email.orEmpty()) }
    var password by remember { mutableStateOf("") }
    var isSignUp by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var stores by remember { mutableStateOf(emptyList<StoreInfo>()) }
    var currentStore by remember { mutableStateOf<StoreInfo?>(null) }
    var products by remember { mutableStateOf(emptyList<ProductInfo>()) }
    var search by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf("Catalogue") }
    var storeName by remember { mutableStateOf("") }
    var inviteCode by remember { mutableStateOf("") }
    var inviteResult by remember { mutableStateOf("") }
    var productName by remember { mutableStateOf("") }
    var productPrice by remember { mutableStateOf("") }
    var selectedPhoto by remember { mutableStateOf<Uri?>(null) }
    var noteText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf(emptyList<NoteInfo>()) }
    var priceProduct by remember { mutableStateOf<ProductInfo?>(null) }
    var reauthPassword by remember { mutableStateOf("") }
    var newPrice by remember { mutableStateOf("") }
    var showPriceDialog by remember { mutableStateOf(false) }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { selectedPhoto = it }

    fun launchTask(task: suspend () -> Unit) {
        scope.launch {
            busy = true; message = ""
            try { task() } catch (e: Exception) { message = e.message ?: "Something went wrong." }
            finally { busy = false }
        }
    }
    fun reloadStores() = launchTask {
        stores = withContext(Dispatchers.IO) { api.myStores() }
        if (currentStore == null) currentStore = stores.firstOrNull()
        else currentStore = stores.firstOrNull { it.id == currentStore?.id } ?: stores.firstOrNull()
        val s = currentStore
        if (s != null) {
            val fresh = try { withContext(Dispatchers.IO) { api.products(s.id) } } catch (e: Exception) { api.cachedProducts(context, s.id).also { if (it.isEmpty()) throw e; message = "Offline mode: showing saved catalogue." } }
            products = fresh
            if (fresh.isNotEmpty()) withContext(Dispatchers.IO) { api.cacheProducts(context, s.id, fresh) }
        }
    }
    LaunchedEffect(signedIn) {
        if (signedIn) {
            try {
                stores = try { withContext(Dispatchers.IO) { api.myStores() }.also { api.cacheStores(context, it) } }
                catch (_: Exception) { api.cachedStores(context) }
                currentStore = stores.firstOrNull()
                val s = currentStore
                if (s != null) {
                    products = try { withContext(Dispatchers.IO) { api.products(s.id) }.also { withContext(Dispatchers.IO) { api.cacheProducts(context, s.id, it) } } }
                    catch (_: Exception) { api.cachedProducts(context, s.id).also { if (it.isNotEmpty()) message = "Offline mode: showing saved catalogue." } }
                }
            } catch (e: Exception) { message = e.message ?: "Could not load your stores." }
        }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("StoreSync", style = MaterialTheme.typography.titleLarge) }, actions = {
            if (signedIn) IconButton(onClick = { reloadStores() }, enabled = !busy) { Icon(Icons.Default.Refresh, contentDescription = "Refresh") }
        })
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (message.isNotBlank()) Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer), modifier = Modifier.fillMaxWidth()) { Text(message, Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onErrorContainer) }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (!signedIn) {
                Spacer(Modifier.height(35.dp))
                Text(if (isSignUp) "Create your account" else "Sign in", style = MaterialTheme.typography.headlineMedium)
                Text("Your catalogue stays connected to your store.", style = MaterialTheme.typography.bodyMedium)
                OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), label = { Text("Email") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
                OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(), label = { Text("Password") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                Button(onClick = { launchTask { withContext(Dispatchers.IO) { if (isSignUp) api.signUp(email.trim(), password) else api.signIn(email.trim(), password) }; signedIn = api.signedIn; if (!signedIn) message = "Account request completed. Confirm your email if requested, then sign in." } }, Modifier.fillMaxWidth(), enabled = !busy && email.contains("@") && password.length >= 6) { Text(if (isSignUp) "Create account" else "Sign in") }
                TextButton(onClick = { isSignUp = !isSignUp; message = "" }) { Text(if (isSignUp) "Already have an account? Sign in" else "New to StoreSync? Create account") }
                Text("Use the same account on your devices. Keep your password private.", style = MaterialTheme.typography.bodySmall)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.weight(1f)) { Text(email, style = MaterialTheme.typography.labelMedium); Text(currentStore?.name ?: "No store selected", style = MaterialTheme.typography.titleMedium) }
                    TextButton(onClick = { api.signOut(); signedIn = false; stores = emptyList(); currentStore = null; products = emptyList(); password = "" }) { Text("Sign out") }
                }
                if (stores.size > 1) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { stores.forEach { s -> FilterChip(selected = currentStore?.id == s.id, onClick = { currentStore = s; tab = "Catalogue"; launchTask { products = withContext(Dispatchers.IO) { api.products(s.id) }.also { withContext(Dispatchers.IO) { api.cacheProducts(context,s.id,it) } } } }, label = { Text(s.name) }) } }
                if (stores.isEmpty()) {
                    Text("Set up your first store", style = MaterialTheme.typography.headlineSmall)
                    Text("Create a store as an Admin, or enter an invitation code from an existing store Admin.")
                    OutlinedTextField(storeName, { storeName = it }, Modifier.fillMaxWidth(), label = { Text("New store name") }, singleLine = true)
                    Button(onClick = { launchTask { withContext(Dispatchers.IO) { api.createStore(storeName.trim()) }; storeName = ""; stores = withContext(Dispatchers.IO) { api.myStores() }; currentStore = stores.firstOrNull(); message = "Store created. You are its Admin." } }, enabled = !busy && storeName.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Create store") }
                    HorizontalDivider()
                    OutlinedTextField(inviteCode, { inviteCode = it }, Modifier.fillMaxWidth(), label = { Text("Salesperson invitation code") }, singleLine = true)
                    Button(onClick = { launchTask { withContext(Dispatchers.IO) { api.joinStore(inviteCode.trim()) }; inviteCode = ""; stores = withContext(Dispatchers.IO) { api.myStores() }; currentStore = stores.firstOrNull(); message = "You joined the store." } }, enabled = !busy && inviteCode.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Join store") }
                } else {
                    val store = currentStore
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        listOf("Catalogue", "Notes", "Manage").forEach { t -> FilterChip(selected = tab == t, onClick = { tab = t; if (t == "Notes" && store != null) launchTask { notes = withContext(Dispatchers.IO) { api.notes(store.id) } } }, label = { Text(t) }) }
                    }
                    when (tab) {
                        "Catalogue" -> {
                            OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth(), label = { Text("Search products") }, singleLine = true)
                            Text("${products.size} saved products · Catalogue can be viewed offline", style = MaterialTheme.typography.bodySmall)
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                                items(products.filter { it.name.contains(search, true) }) { p ->
                                    Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) { Text(p.name, style = MaterialTheme.typography.titleMedium); Text(NumberFormat.getCurrencyInstance(Locale("en", "NG")).format(p.price), style = MaterialTheme.typography.bodyLarge) }
                                        if (store?.role == "admin") TextButton(onClick = { priceProduct = p; newPrice = p.price.toString(); reauthPassword = ""; showPriceDialog = true }) { Text("Change price") }
                                    } }
                                }
                            }
                        }
                        "Notes" -> {
                            if (store?.role == "salesperson") {
                                Text("Send a note to the Admin", style = MaterialTheme.typography.titleMedium)
                                OutlinedTextField(noteText, { noteText = it }, Modifier.fillMaxWidth(), label = { Text("Your note") }, minLines = 3)
                                Button(onClick = { launchTask { withContext(Dispatchers.IO) { api.sendNote(store.id, noteText.trim()) }; noteText = ""; message = "Note sent to the Admin." } }, enabled = !busy && noteText.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Send note") }
                            } else {
                                Text("Salesperson notes", style = MaterialTheme.typography.titleMedium)
                                Button(onClick = { launchTask { notes = withContext(Dispatchers.IO) { api.notes(store!!.id) } } }) { Text("Load notes") }
                                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(notes) { n -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text(n.note); Text(n.createdAt, style = MaterialTheme.typography.labelSmall) } } } }
                            }
                        }
                        else -> {
                            if (store?.role == "admin") {
                                Text("Admin tools", style = MaterialTheme.typography.titleMedium)
                                Text("Product and price changes require an internet connection. Salespersons can only browse and send notes.")
                                HorizontalDivider()
                                Text("Add product", style = MaterialTheme.typography.titleMedium)
                                OutlinedTextField(productName, { productName = it }, Modifier.fillMaxWidth(), label = { Text("Product name") }, singleLine = true)
                                OutlinedTextField(productPrice, { productPrice = it }, Modifier.fillMaxWidth(), label = { Text("Price (NGN)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                                OutlinedButton(onClick = { photoPicker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Text(if (selectedPhoto == null) "Choose product photo (optional)" else "Photo selected — choose another") }
                                Button(onClick = { launchTask { val price=productPrice.toDoubleOrNull() ?: throw IllegalArgumentException("Enter a valid price."); if(price<0) throw IllegalArgumentException("Price cannot be negative."); withContext(Dispatchers.IO) { api.addProduct(store.id,productName.trim(),price,selectedPhoto,context) }; productName=""; productPrice=""; selectedPhoto=null; products=withContext(Dispatchers.IO) { api.products(store.id) }; withContext(Dispatchers.IO) { api.cacheProducts(context,store.id,products) }; message="Product added." } }, enabled = !busy && productName.isNotBlank() && (productPrice.toDoubleOrNull() ?: -1.0) >= 0, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add product") }
                                HorizontalDivider()
                                Text("Invite a salesperson", style = MaterialTheme.typography.titleMedium)
                                Button(onClick = { launchTask { inviteResult = withContext(Dispatchers.IO) { api.createInvite(store.id) }; message = "Share this code with the salesperson: $inviteResult" } }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Generate invitation code") }
                                if (inviteResult.isNotBlank()) Text("Invitation code: $inviteResult", style = MaterialTheme.typography.titleMedium)
                            } else Text("Admin-only tools", style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
        }
    }
    if (showPriceDialog && priceProduct != null) {
        AlertDialog(onDismissRequest = { showPriceDialog = false }, title = { Text("Change product price") }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${priceProduct!!.name}. Confirm your Admin password before saving.")
                OutlinedTextField(reauthPassword, { reauthPassword = it }, label = { Text("Admin password") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(newPrice, { newPrice = it }, label = { Text("New price (NGN)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            }
        }, confirmButton = { Button(enabled = !busy && reauthPassword.isNotBlank() && (newPrice.toDoubleOrNull() ?: -1.0) >= 0, onClick = { val p=priceProduct!!; val pw=reauthPassword; val amount=newPrice.toDoubleOrNull()!!; launchTask { withContext(Dispatchers.IO) { api.verifyPassword(pw); api.updatePrice(p.id,amount) }; val s=currentStore!!; products=withContext(Dispatchers.IO) { api.products(s.id) }; withContext(Dispatchers.IO) { api.cacheProducts(context,s.id,products) }; showPriceDialog=false; reauthPassword=""; message="Price updated." } }) { Text("Verify and save") } }, dismissButton = { TextButton(onClick = { showPriceDialog=false }) { Text("Cancel") } })
    }
}
