package com.storesync.app

/** Paste your Supabase project URL and publishable key here. Never put a service_role/secret key in an app. */
object AppConfig {
    const val SUPABASE_URL = "https://xqdmphoauocapyiuhdct.supabase.co"
    const val SUPABASE_PUBLISHABLE_KEY = "PASTE_YOUR_SB_PUBLISHABLE_KEY_HERE"
    const val STORAGE_BUCKET = "product-images"
}
