# StoreSync v6 — shared catalogue upgrade

This version keeps the existing Supabase project, product rows, photos, and shared management password. It adds:

- Product Updates tab using each product's `updated_at` timestamp.
- Eye buttons to show/hide management passwords while typing.
- Swipe editing: managers can change the product name, main price, two optional unit prices, and photo on the swipe card, then Save & Next.
- Shared Notes tab. Anyone can add a name tag and post notes without the management password; all users can read them.
- Two optional custom unit prices per product, each with its own unit label.
- A StoreSync launcher icon.

## IMPORTANT: run the database upgrade before installing this APK

1. Open the Supabase project SQL Editor.
2. Run `backend/05_storesync_upgrade.sql` in full.
3. This adds nullable unit-price columns, update-time tracking, and shared notes/tags. It does not delete or replace existing products, photos, or the management password.
4. If the SQL editor reports an error, stop and share the exact error before installing the APK.

The existing `03_password_catalogue.sql` and `04_product_photo_picker.sql` have already been applied in the live project. Do not rerun them just for this upgrade.

## Build with GitHub Actions

- Keep the existing repository secret `SUPABASE_PUBLISHABLE_KEY`.
- Upload `StoreSync_v6_Notes_Units_Updates.zip` to the repository root.
- Replace the workflow file `.github/workflows/build.yml` with the complete contents of `GITHUB_ACTIONS_WORKFLOW.txt`.
- Run the workflow and download the artifact `StoreSync-v6-Notes-Units-Updates-APK`.

## Notes and access

The notes feature is intentionally open to anonymous users so anyone with the app can add notes. Name tags are labels, not verified identities. Anyone can create a tag using another person's name, so do not treat them as secure authentication or proof of authorship.

The app uses the Supabase publishable key only. Never put a Supabase service-role/secret key in the APK.
