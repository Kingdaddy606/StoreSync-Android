package com.storesync.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        val api = StoreSyncApi(this)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF176B4D))) { StoreSyncScreen(api) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StoreSyncScreen(api: StoreSyncApi) {
    val scope = rememberCoroutineScope()
    var products by remember { mutableStateOf(emptyList<ProductInfo>()) }
    var search by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Loading catalogue…") }
    var management by remember { mutableStateOf(false) }
    var password by remember { mutableStateOf("") }
    var currentPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordSet by remember { mutableStateOf<Boolean?>(null) }
    var setupMode by remember { mutableStateOf(false) }
    var showPassword by remember { mutableStateOf(false) }
    var showNewPassword by remember { mutableStateOf(false) }
    var showConfirmPassword by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf("Scroll") }
    var tab by remember { mutableStateOf("Catalogue") }
    var editProduct by remember { mutableStateOf<ProductInfo?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var imageUrl by remember { mutableStateOf("") }
    var unit1Name by remember { mutableStateOf("") }
    var unit1Price by remember { mutableStateOf("") }
    var unit2Name by remember { mutableStateOf("") }
    var unit2Price by remember { mutableStateOf("") }
    var swipeIndex by remember { mutableIntStateOf(0) }
    var swipeName by remember { mutableStateOf("") }
    var swipePrice by remember { mutableStateOf("") }
    var swipeUnit1Name by remember { mutableStateOf("") }
    var swipeUnit1Price by remember { mutableStateOf("") }
    var swipeUnit2Name by remember { mutableStateOf("") }
    var swipeUnit2Price by remember { mutableStateOf("") }
    var showAccessDialog by remember { mutableStateOf(false) }
    var showPasswordChange by remember { mutableStateOf(false) }
    var tags by remember { mutableStateOf(emptyList<NoteTag>()) }
    var notes by remember { mutableStateOf(emptyList<SharedNote>()) }
    var selectedTag by remember { mutableStateOf("") }
    var noteBody by remember { mutableStateOf("") }
    var newTagName by remember { mutableStateOf("") }
    var showTagDialog by remember { mutableStateOf(false) }

    fun runTask(success: String, task: suspend () -> Unit) {
        scope.launch { busy = true; message = ""; try { task(); message = success } catch (e: Exception) { message = e.message ?: "Something went wrong." } finally { busy = false } }
    }
    fun refreshProducts() {
        runTask("Catalogue refreshed.") { products = withContext(Dispatchers.IO) { api.products() }; withContext(Dispatchers.IO) { api.cacheProducts(products) }; passwordSet = withContext(Dispatchers.IO) { api.hasPassword() } }
    }
    fun loadNotes() {
        runTask("Notes refreshed.") { tags = withContext(Dispatchers.IO) { api.noteTags() }; notes = withContext(Dispatchers.IO) { api.notes() }; if (selectedTag.isBlank() && tags.isNotEmpty()) selectedTag = tags.first().name }
    }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) runTask("Photo uploaded.") { imageUrl = withContext(Dispatchers.IO) { api.uploadProductPhoto(uri, password) } }
    }
    LaunchedEffect(Unit) {
        products = api.cachedProducts()
        try { products = withContext(Dispatchers.IO) { api.products() }; api.cacheProducts(products); passwordSet = withContext(Dispatchers.IO) { api.hasPassword() }; message = "" }
        catch (e: Exception) { message = if (products.isNotEmpty()) "Offline mode — showing saved prices." else (e.message ?: "Could not load catalogue.") }
    }
    LaunchedEffect(tab) { if (tab == "Notes") { try { tags = withContext(Dispatchers.IO) { api.noteTags() }; notes = withContext(Dispatchers.IO) { api.notes() }; if (selectedTag.isBlank() && tags.isNotEmpty()) selectedTag = tags.first().name } catch (e: Exception) { message = e.message ?: "Could not load notes." } } }

    val visible = products.filter { it.name.contains(search, true) }
    fun startEdit(p: ProductInfo?) {
        editProduct = p; name = p?.name.orEmpty(); price = p?.price?.toString().orEmpty(); imageUrl = p?.imageUrl.orEmpty()
        unit1Name = p?.unit1Name.orEmpty(); unit1Price = p?.unit1Price?.toString().orEmpty(); unit2Name = p?.unit2Name.orEmpty(); unit2Price = p?.unit2Price?.toString().orEmpty(); showEditor = true
    }
    fun beginSwipeEdit(p: ProductInfo) {
        swipeName = p.name; swipePrice = p.price.toString(); imageUrl = p.imageUrl.orEmpty()
        swipeUnit1Name = p.unit1Name.orEmpty(); swipeUnit1Price = p.unit1Price?.toString().orEmpty(); swipeUnit2Name = p.unit2Name.orEmpty(); swipeUnit2Price = p.unit2Price?.toString().orEmpty()
    }
    fun dateLabel(value: String?): String {
        if (value.isNullOrBlank()) return "Update time unavailable"
        return try { DateTimeFormatter.ofPattern("dd MMM yyyy, h:mm a", Locale.getDefault()).withZone(ZoneId.systemDefault()).format(Instant.parse(value)) } catch (_: Exception) { value }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("StoreSync") }, actions = { IconButton(onClick = { if (tab == "Notes") loadNotes() else refreshProducts() }, enabled = !busy) { Icon(Icons.Default.Refresh, "Refresh") } })
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (message.isNotBlank()) Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            TabRow(selectedTabIndex = listOf("Catalogue", "Updates", "Notes").indexOf(tab).coerceAtLeast(0)) {
                listOf("Catalogue", "Updates", "Notes").forEach { label -> Tab(selected = tab == label, onClick = { tab = label }, text = { Text(label) }) }
            }
            when (tab) {
                "Catalogue" -> {
                    OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth(), label = { Text("Search products") }, singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) })
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${visible.size} products", Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
                        TextButton(onClick = { mode = "Scroll" }) { Text("Scroll") }
                        TextButton(onClick = { mode = "Swipe" }) { Text("Swipe") }
                        Button(onClick = { management = false; password = ""; setupMode = false; showAccessDialog = true }) { Text("Manage") }
                    }
                    if (visible.isEmpty()) Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { Text(if (products.isEmpty()) "No products yet. Unlock management to add your first product." else "No matching products.") }
                    else if (mode == "Swipe") {
                        val index = swipeIndex.coerceIn(0, visible.lastIndex)
                        val p = visible[index]
                        LaunchedEffect(p.id, management) { if (management) beginSwipeEdit(p) }
                        Card(Modifier.fillMaxWidth().weight(1f).pointerInput(visible, index, management) { var delta = 0f; detectHorizontalDragGestures(onHorizontalDrag = { _, d -> delta += d }, onDragEnd = { if (delta < -45) swipeIndex = (index + 1).coerceAtMost(visible.lastIndex) else if (delta > 45) swipeIndex = (index - 1).coerceAtLeast(0); delta = 0f }) }, shape = RoundedCornerShape(24.dp)) {
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${index + 1} / ${visible.size}", style = MaterialTheme.typography.labelSmall)
                                val swipeImage = if (management) imageUrl else p.imageUrl
                                if (!swipeImage.isNullOrBlank()) AsyncImage(model = swipeImage, contentDescription = p.name, modifier = Modifier.fillMaxWidth().height(if (management) 64.dp else 150.dp))
                                if (management) {
                                    OutlinedTextField(swipeName, { swipeName = it }, Modifier.fillMaxWidth().height(56.dp), label = { Text("Product name") }, singleLine = true, textStyle = MaterialTheme.typography.bodyMedium)
                                    OutlinedTextField(swipePrice, { swipePrice = it }, Modifier.fillMaxWidth().height(56.dp), label = { Text("Main price (₦)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, textStyle = MaterialTheme.typography.bodyMedium)
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        OutlinedTextField(swipeUnit1Name, { swipeUnit1Name = it }, Modifier.weight(1f).height(56.dp), label = { Text("Unit 1 name") }, singleLine = true, textStyle = MaterialTheme.typography.bodySmall)
                                        OutlinedTextField(swipeUnit1Price, { swipeUnit1Price = it }, Modifier.weight(1f).height(56.dp), label = { Text("Price ₦") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, textStyle = MaterialTheme.typography.bodySmall)
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        OutlinedTextField(swipeUnit2Name, { swipeUnit2Name = it }, Modifier.weight(1f).height(56.dp), label = { Text("Unit 2 name") }, singleLine = true, textStyle = MaterialTheme.typography.bodySmall)
                                        OutlinedTextField(swipeUnit2Price, { swipeUnit2Price = it }, Modifier.weight(1f).height(56.dp), label = { Text("Price ₦") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, textStyle = MaterialTheme.typography.bodySmall)
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick = { photoPicker.launch("image/*") }, modifier = Modifier.weight(0.8f)) { Icon(Icons.Default.AddPhotoAlternate, null); Text(" Photo") }
                                        Button(enabled = !busy && swipeName.isNotBlank() && (swipePrice.toDoubleOrNull() ?: -1.0) >= 0, modifier = Modifier.weight(1.2f), onClick = {
                                            runTask("Changes saved.") { withContext(Dispatchers.IO) { api.updateProduct(password, p.id, swipeName.trim(), swipePrice.toDouble(), imageUrl.ifBlank { null }, swipeUnit1Name.trim().ifBlank { null }, swipeUnit1Price.toDoubleOrNull(), swipeUnit2Name.trim().ifBlank { null }, swipeUnit2Price.toDoubleOrNull()); products = api.products(); api.cacheProducts(products) }; swipeIndex = (index + 1).coerceAtMost((visible.size - 1).coerceAtLeast(0)) }
                                        }) { Icon(Icons.Default.Save, null); Text(" Save & next") }
                                    }
                                } else {
                                    Text(p.name, style = MaterialTheme.typography.headlineMedium)
                                    Text(naira(p.price), style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
                                    p.unit1Name?.let { Text("$it: ${p.unit1Price?.let(::naira).orEmpty()}") }
                                    p.unit2Name?.let { Text("$it: ${p.unit2Price?.let(::naira).orEmpty()}") }
                                }
                                Text("Swipe left or right to move between products", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { TextButton(onClick = { swipeIndex = (index - 1).coerceAtLeast(0) }) { Text("Previous") }; TextButton(onClick = { swipeIndex = (index + 1).coerceAtMost(visible.lastIndex) }) { Text("Next") } }
                    } else {
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(visible, key = { it.id }) { p -> Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (!p.imageUrl.isNullOrBlank()) AsyncImage(model = p.imageUrl, contentDescription = p.name, modifier = Modifier.size(64.dp))
                                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                                    Text(p.name, style = MaterialTheme.typography.titleMedium); Text(naira(p.price), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.primary)
                                    if (p.unit1Name != null) Text("${p.unit1Name}: ${p.unit1Price?.let(::naira).orEmpty()}", style = MaterialTheme.typography.bodySmall)
                                    if (p.unit2Name != null) Text("${p.unit2Name}: ${p.unit2Price?.let(::naira).orEmpty()}", style = MaterialTheme.typography.bodySmall)
                                }
                                if (management) IconButton(onClick = { startEdit(p) }) { Icon(Icons.Default.Edit, "Edit product") }
                            } } }
                        }
                    }
                    if (management) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { startEdit(null) }, enabled = !busy, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Add, null); Text(" Add product") }
                        OutlinedButton(onClick = { showPasswordChange = true }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Lock, null); Text(" Password") }
                        TextButton(onClick = { management = false; password = "" }) { Text("Lock") }
                    }
                }
                "Updates" -> {
                    Text("Latest product updates", style = MaterialTheme.typography.titleMedium)
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(products.sortedByDescending { it.updatedAt ?: "" }, key = { it.id }) { p -> Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (!p.imageUrl.isNullOrBlank()) AsyncImage(model = p.imageUrl, contentDescription = p.name, modifier = Modifier.size(52.dp))
                            Column(Modifier.weight(1f).padding(start = 10.dp)) { Text(p.name, style = MaterialTheme.typography.titleMedium); Text("Price: ${naira(p.price)}", color = MaterialTheme.colorScheme.primary); Text("Last updated: ${dateLabel(p.updatedAt)}", style = MaterialTheme.typography.bodySmall) }
                        } } }
                    }
                }
                "Notes" -> {
                    Text("Shared store notes", style = MaterialTheme.typography.titleMedium)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Name tags", Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
                        IconButton(onClick = { newTagName = ""; showTagDialog = true }) { Icon(Icons.Default.AddCircle, "Add name tag") }
                    }
                    if (tags.isEmpty()) Text("Add your name with the + button before writing a note.", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { tags.forEach { t -> FilterChip(selected = selectedTag == t.name, onClick = { selectedTag = t.name }, label = { Text(t.name) }) } }
                    OutlinedTextField(noteBody, { noteBody = it }, Modifier.fillMaxWidth(), label = { Text("Write a note for everyone") }, minLines = 2)
                    Button(enabled = !busy && noteBody.isNotBlank() && selectedTag.isNotBlank(), onClick = { val body = noteBody.trim(); val author = selectedTag; runTask("Note shared with everyone.") { withContext(Dispatchers.IO) { api.addNote(body, author); notes = api.notes() }; noteBody = "" } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Send, null); Text(" Post note") }
                    Text("Everyone can read and add notes without the management password.", style = MaterialTheme.typography.bodySmall)
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(notes, key = { it.id }) { n -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            AssistChip(onClick = {}, label = { Text(n.author) })
                            Text(n.body)
                            Text(dateLabel(n.createdAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                        } } }
                    }
                }
            }
        }
    }

    if (showAccessDialog) AlertDialog(onDismissRequest = { showAccessDialog = false }, title = { Text("Management access") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        when (passwordSet) {
            null -> Text("Checking password setup…")
            false -> {
                Text("Create the shared management password. Anyone who knows it can manage this catalogue.")
                OutlinedTextField(newPassword, { newPassword = it }, label = { Text("Create password") }, visualTransformation = if (showNewPassword) VisualTransformation.None else PasswordVisualTransformation(), singleLine = true, trailingIcon = { IconButton(onClick = { showNewPassword = !showNewPassword }) { Icon(if (showNewPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility, "Show or hide password") } })
                OutlinedTextField(confirmPassword, { confirmPassword = it }, label = { Text("Confirm password") }, visualTransformation = if (showConfirmPassword) VisualTransformation.None else PasswordVisualTransformation(), singleLine = true, trailingIcon = { IconButton(onClick = { showConfirmPassword = !showConfirmPassword }) { Icon(if (showConfirmPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility, "Show or hide password") } })
            }
            true -> {
                Text("Enter the shared password to add, edit or delete products.")
                OutlinedTextField(password, { password = it }, label = { Text("Management password") }, visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(), singleLine = true, trailingIcon = { IconButton(onClick = { showPassword = !showPassword }) { Icon(if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility, "Show or hide password") } })
            }
        }
    } }, confirmButton = { Button(enabled = !busy && when (passwordSet) { false -> newPassword.length >= 8 && newPassword == confirmPassword; true -> password.isNotBlank(); else -> false }, onClick = { runTask("Management unlocked.") { withContext(Dispatchers.IO) { if (passwordSet == false) api.initializePassword(newPassword) else if (!api.verifyPassword(password)) throw IllegalArgumentException("Incorrect management password.") }; management = true; showAccessDialog = false; password = if (passwordSet == false) newPassword else password; passwordSet = true; newPassword = ""; confirmPassword = "" } }) { Text(if (passwordSet == false) "Create password" else "Unlock") } }, dismissButton = { TextButton(onClick = { showAccessDialog = false }) { Text("Cancel") } })

    if (showPasswordChange) AlertDialog(onDismissRequest = { showPasswordChange = false }, title = { Text("Change shared password") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(currentPassword, { currentPassword = it }, label = { Text("Current password") }, visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { IconButton(onClick = { showPassword = !showPassword }) { Icon(if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility, null) } })
        OutlinedTextField(newPassword, { newPassword = it }, label = { Text("New password (8+ characters)") }, visualTransformation = if (showNewPassword) VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { IconButton(onClick = { showNewPassword = !showNewPassword }) { Icon(if (showNewPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility, null) } })
        OutlinedTextField(confirmPassword, { confirmPassword = it }, label = { Text("Confirm new password") }, visualTransformation = if (showConfirmPassword) VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { IconButton(onClick = { showConfirmPassword = !showConfirmPassword }) { Icon(if (showConfirmPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility, null) } })
    } }, confirmButton = { Button(enabled = !busy && currentPassword.isNotBlank() && newPassword.length >= 8 && newPassword == confirmPassword, onClick = { runTask("Shared password changed.") { withContext(Dispatchers.IO) { api.changePassword(currentPassword, newPassword) }; password = newPassword; showPasswordChange = false; currentPassword = ""; newPassword = ""; confirmPassword = "" } }) { Text("Change password") } }, dismissButton = { TextButton(onClick = { showPasswordChange = false }) { Text("Cancel") } })

    if (showEditor) AlertDialog(onDismissRequest = { showEditor = false }, title = { Text(if (editProduct == null) "Add product" else "Edit product") }, text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        OutlinedTextField(name, { name = it }, label = { Text("Product name") }, singleLine = true)
        OutlinedTextField(price, { price = it }, label = { Text("Main price (₦)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { OutlinedTextField(unit1Name, { unit1Name = it }, Modifier.weight(1f), label = { Text("Unit 1 name") }, singleLine = true); OutlinedTextField(unit1Price, { unit1Price = it }, Modifier.weight(1f), label = { Text("Price ₦") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)) }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { OutlinedTextField(unit2Name, { unit2Name = it }, Modifier.weight(1f), label = { Text("Unit 2 name") }, singleLine = true); OutlinedTextField(unit2Price, { unit2Price = it }, Modifier.weight(1f), label = { Text("Price ₦") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)) }
        OutlinedButton(onClick = { photoPicker.launch("image/*") }, enabled = !busy) { Icon(Icons.Default.AddPhotoAlternate, null); Text(if (imageUrl.isBlank()) " Choose product photo" else " Change product photo") }
        if (imageUrl.isNotBlank()) Text("Photo selected and uploaded", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
    } }, confirmButton = { Button(enabled = !busy && name.isNotBlank() && (price.toDoubleOrNull() ?: -1.0) >= 0, onClick = { val p = editProduct; val n = name.trim(); val amount = price.toDoubleOrNull()!!; val url = imageUrl.trim().ifBlank { null }; runTask("Product saved.") { withContext(Dispatchers.IO) { if (p == null) api.addProduct(password, n, amount, url, unit1Name.trim().ifBlank { null }, unit1Price.toDoubleOrNull(), unit2Name.trim().ifBlank { null }, unit2Price.toDoubleOrNull()) else api.updateProduct(password, p.id, n, amount, url, unit1Name.trim().ifBlank { null }, unit1Price.toDoubleOrNull(), unit2Name.trim().ifBlank { null }, unit2Price.toDoubleOrNull()); products = api.products(); api.cacheProducts(products) }; showEditor = false } }) { Text("Save") } }, dismissButton = { Row { if (editProduct != null) TextButton(onClick = { val p = editProduct!!; runTask("Product deleted.") { withContext(Dispatchers.IO) { api.deleteProduct(password, p.id); products = api.products(); api.cacheProducts(products) }; showEditor = false } }) { Text("Delete", color = MaterialTheme.colorScheme.error) }; TextButton(onClick = { showEditor = false }) { Text("Cancel") } } })

    if (showTagDialog) AlertDialog(onDismissRequest = { showTagDialog = false }, title = { Text("Add a name tag") }, text = { OutlinedTextField(newTagName, { newTagName = it }, label = { Text("Your name") }, singleLine = true) }, confirmButton = { Button(enabled = newTagName.isNotBlank() && !busy, onClick = { val tag = newTagName.trim(); runTask("Name tag added.") { val created = withContext(Dispatchers.IO) { api.addNoteTag(tag) }; tags = (tags + created).distinctBy { it.id }; selectedTag = created.name; showTagDialog = false } }) { Text("Add tag") } }, dismissButton = { TextButton(onClick = { showTagDialog = false }) { Text("Cancel") } })
}

private fun naira(value: Double): String = NumberFormat.getCurrencyInstance(Locale("en", "NG")).format(value)
