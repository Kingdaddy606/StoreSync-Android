package com.storesync.app

import android.content.Context
import android.net.Uri
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.TimeUnit

 data class ProductInfo(
    val id: String,
    val name: String,
    val price: Double,
    val imageUrl: String? = null,
    val updatedAt: String? = null,
    val unit1Name: String? = null,
    val unit1Price: Double? = null,
    val unit2Name: String? = null,
    val unit2Price: Double? = null
)

data class NoteTag(val id: String, val name: String)
data class SharedNote(val id: String, val body: String, val author: String, val createdAt: String)

class StoreSyncApi(private val context: Context) {
    private val prefs = context.getSharedPreferences("storesync_catalogue", Context.MODE_PRIVATE)
    private val client = OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
    private val base get() = AppConfig.SUPABASE_URL.trimEnd('/')
    private val key get() = AppConfig.SUPABASE_PUBLISHABLE_KEY

    private fun request(method: String, path: String, body: String? = null, extraHeaders: Map<String, String> = emptyMap()): String {
        if (key.startsWith("PASTE_")) throw IOException("Setup needed: add your Supabase publishable key in GitHub Actions secrets.")
        val b = Request.Builder().url("$base$path").header("apikey", key).header("Authorization", "Bearer $key").header("Accept", "application/json")
        extraHeaders.forEach { (k, v) -> b.header(k, v) }
        when (method) {
            "GET" -> b.get()
            "PATCH" -> b.patch((body ?: "{}").toRequestBody("application/json; charset=utf-8".toMediaType()))
            "DELETE" -> b.delete()
            else -> b.post((body ?: "{}").toRequestBody("application/json; charset=utf-8".toMediaType()))
        }
        client.newCall(b.build()).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (!r.isSuccessful) {
                val detail = try { JSONObject(text).optString("message", JSONObject(text).optString("details", text)) } catch (_: Exception) { text }
                throw IOException("Server ${r.code}: $detail")
            }
            return text
        }
    }
    private fun rpc(name: String, args: JSONObject): String = request("POST", "/rest/v1/rpc/$name", args.toString())
    private fun enc(value: String) = URLEncoder.encode(value, "UTF-8").replace("+", "%20")
    private fun parseProduct(o: JSONObject) = ProductInfo(
        o.getString("id"), o.optString("name"), o.optDouble("price"),
        o.optString("image_url").takeIf { it.isNotBlank() && it != "null" },
        o.optString("updated_at").takeIf { it.isNotBlank() && it != "null" },
        o.optString("unit_1_name").takeIf { it.isNotBlank() && it != "null" },
        o.optDouble("unit_1_price").takeIf { !o.isNull("unit_1_price") },
        o.optString("unit_2_name").takeIf { it.isNotBlank() && it != "null" },
        o.optDouble("unit_2_price").takeIf { !o.isNull("unit_2_price") }
    )

    fun uploadProductPhoto(uri: Uri, managementPassword: String): String {
        if (!verifyPassword(managementPassword)) throw IOException("Incorrect management password.")
        val resolver = context.contentResolver
        val mime = resolver.getType(uri) ?: "image/jpeg"
        if (!mime.startsWith("image/")) throw IOException("Please choose an image file.")
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("Could not read the selected photo.")
        if (bytes.size > 5 * 1024 * 1024) throw IOException("Photo must be 5 MB or smaller.")
        val ext = when (mime.lowercase()) { "image/png" -> "png"; "image/webp" -> "webp"; "image/heic" -> "heic"; else -> "jpg" }
        val objectName = "catalogue/${UUID.randomUUID()}.$ext"
        val encoded = objectName.split("/").joinToString("/") { enc(it) }
        val req = Request.Builder().url("$base/storage/v1/object/product-images/$encoded").header("apikey", key).header("Authorization", "Bearer $key").header("Content-Type", mime).header("x-upsert", "false").post(bytes.toRequestBody(mime.toMediaType())).build()
        client.newCall(req).execute().use { response -> val body = response.body?.string().orEmpty(); if (!response.isSuccessful) throw IOException("Photo upload failed (${response.code}): $body") }
        return "$base/storage/v1/object/public/product-images/$encoded"
    }

    fun products(): List<ProductInfo> {
        val a = JSONArray(request("GET", "/rest/v1/shared_catalogue_products?select=id,name,price,image_url,updated_at,unit_1_name,unit_1_price,unit_2_name,unit_2_price&order=name.asc"))
        return (0 until a.length()).map { parseProduct(a.getJSONObject(it)) }
    }
    fun cachedProducts(): List<ProductInfo> {
        val a = try { JSONArray(prefs.getString("products", "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until a.length()).map { parseProduct(a.getJSONObject(it)) }
    }
    fun cacheProducts(list: List<ProductInfo>) {
        val a = JSONArray()
        list.forEach { p -> a.put(JSONObject().put("id",p.id).put("name",p.name).put("price",p.price).put("image_url",p.imageUrl).put("updated_at",p.updatedAt).put("unit_1_name",p.unit1Name).put("unit_1_price",p.unit1Price).put("unit_2_name",p.unit2Name).put("unit_2_price",p.unit2Price)) }
        prefs.edit().putString("products", a.toString()).apply()
    }
    fun hasPassword(): Boolean = rpc("management_password_is_set", JSONObject()).trim().equals("true", true)
    fun initializePassword(newPassword: String) { rpc("initialize_management_password", JSONObject().put("p_new_password",newPassword)) }
    fun verifyPassword(password: String): Boolean = rpc("verify_management_password", JSONObject().put("p_password",password)).trim().equals("true", true)
    fun changePassword(current: String, next: String) { rpc("change_management_password", JSONObject().put("p_current_password",current).put("p_new_password",next)) }
    fun addProduct(password: String, name: String, price: Double, imageUrl: String?, u1n: String?, u1p: Double?, u2n: String?, u2p: Double?) {
        rpc("management_add_product_v2", JSONObject().put("p_password",password).put("p_name",name).put("p_price",price).put("p_image_url",imageUrl).put("p_unit_1_name",u1n).put("p_unit_1_price",u1p).put("p_unit_2_name",u2n).put("p_unit_2_price",u2p))
    }
    fun updateProduct(password: String, id: String, name: String, price: Double, imageUrl: String?, u1n: String?, u1p: Double?, u2n: String?, u2p: Double?) {
        rpc("management_update_product_v2", JSONObject().put("p_password",password).put("p_product_id",id).put("p_name",name).put("p_price",price).put("p_image_url",imageUrl).put("p_unit_1_name",u1n).put("p_unit_1_price",u1p).put("p_unit_2_name",u2n).put("p_unit_2_price",u2p))
    }
    fun deleteProduct(password: String, id: String) { rpc("management_delete_product", JSONObject().put("p_password",password).put("p_product_id",id)) }

    fun noteTags(): List<NoteTag> {
        val a=JSONArray(request("GET","/rest/v1/shared_note_tags?select=id,name&order=name.asc"))
        return (0 until a.length()).map { val o=a.getJSONObject(it); NoteTag(o.getString("id"),o.getString("name")) }
    }
    fun addNoteTag(name: String): NoteTag {
        val a=JSONArray(request("POST","/rest/v1/shared_note_tags",JSONArray().put(JSONObject().put("name",name.trim())).toString(), mapOf("Prefer" to "return=representation")))
        val o=a.getJSONObject(0); return NoteTag(o.getString("id"),o.getString("name"))
    }
    fun notes(): List<SharedNote> {
        val a=JSONArray(request("GET","/rest/v1/shared_notes?select=id,body,author_name,created_at&order=created_at.desc"))
        return (0 until a.length()).map { val o=a.getJSONObject(it); SharedNote(o.getString("id"),o.getString("body"),o.getString("author_name"),o.optString("created_at")) }
    }
    fun addNote(body: String, author: String) {
        request("POST","/rest/v1/shared_notes",JSONArray().put(JSONObject().put("body",body.trim()).put("author_name",author.trim())).toString(),mapOf("Prefer" to "return=minimal"))
    }
}
