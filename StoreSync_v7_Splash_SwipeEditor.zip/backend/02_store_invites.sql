-- Run this AFTER your original StoreSync database SQL.
-- It adds one-time salesperson invitation codes. Admins generate a code in the app;
-- salespersons create their own account, then redeem that code to join the store.

create table if not exists public.store_invites (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.stores(id) on delete cascade,
  invite_code text not null unique,
  role text not null default 'salesperson' check (role = 'salesperson'),
  created_by uuid not null references auth.users(id) on delete cascade,
  used_by uuid references auth.users(id) on delete set null,
  used_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.store_invites enable row level security;
grant select, insert to authenticated;
grant execute on function public.has_store_role(uuid, text) to authenticated;

drop policy if exists "Admins create salesperson invites" on public.store_invites;
create policy "Admins create salesperson invites"
on public.store_invites for insert to authenticated
with check (
  role = 'salesperson'
  and created_by = auth.uid()
  and public.has_store_role(store_id, 'admin')
);

-- No direct SELECT policy: invite codes can only be consumed by the RPC below.
create or replace function public.join_store_with_code(p_invite_code text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  invite_row public.store_invites%rowtype;
begin
  if auth.uid() is null then
    raise exception 'You must be signed in to join a store';
  end if;

  select * into invite_row
  from public.store_invites si
  where si.invite_code = upper(trim(p_invite_code))
    and si.used_at is null
  for update;

  if not found then
    raise exception 'Invitation code is invalid or has already been used';
  end if;

  if exists (
    select 1 from public.store_members sm
    where sm.store_id = invite_row.store_id and sm.user_id = auth.uid()
  ) then
    raise exception 'You already belong to this store';
  end if;

  insert into public.store_members(store_id, user_id, role)
  values (invite_row.store_id, auth.uid(), 'salesperson');

  update public.store_invites
  set used_by = auth.uid(), used_at = now()
  where id = invite_row.id;
end;
$$;

revoke all on function public.join_store_with_code(text) from public, anon;
grant execute on function public.join_store_with_code(text) to authenticated;
