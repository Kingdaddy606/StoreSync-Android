-- StoreSync upgrade: flexible unit prices, product update timestamps and public shared notes.
-- Run this once in Supabase SQL Editor AFTER keeping a backup of the current database.
-- This migration does not delete existing products, photos, or the management password.

alter table public.shared_catalogue_products
  add column if not exists unit_1_name text,
  add column if not exists unit_1_price numeric(12,2),
  add column if not exists unit_2_name text,
  add column if not exists unit_2_price numeric(12,2);

alter table public.shared_catalogue_products
  drop constraint if exists shared_catalogue_products_unit_1_price_check,
  add constraint shared_catalogue_products_unit_1_price_check check (unit_1_price is null or unit_1_price >= 0),
  drop constraint if exists shared_catalogue_products_unit_2_price_check,
  add constraint shared_catalogue_products_unit_2_price_check check (unit_2_price is null or unit_2_price >= 0);

create or replace function public.storesync_set_updated_at()
returns trigger language plpgsql set search_path = '' as $$
begin
  new.updated_at = now();
  return new;
end; $$;

drop trigger if exists storesync_products_updated_at on public.shared_catalogue_products;
create trigger storesync_products_updated_at
before update on public.shared_catalogue_products
for each row execute function public.storesync_set_updated_at();

-- New RPC names avoid breaking older installed StoreSync APKs during the transition.
create or replace function public.management_add_product_v2(
  p_password text, p_name text, p_price numeric, p_image_url text default null,
  p_unit_1_name text default null, p_unit_1_price numeric default null,
  p_unit_2_name text default null, p_unit_2_price numeric default null
) returns uuid language plpgsql security definer set search_path = '' as $$
declare v_id uuid;
begin
  if not public.verify_management_password(p_password) then raise exception 'Incorrect management password.'; end if;
  if p_name is null or length(trim(p_name)) = 0 or length(trim(p_name)) > 160 then raise exception 'Enter a valid product name.'; end if;
  if p_price is null or p_price < 0 then raise exception 'Enter a valid main price.'; end if;
  if p_unit_1_price is not null and p_unit_1_price < 0 then raise exception 'Unit 1 price cannot be negative.'; end if;
  if p_unit_2_price is not null and p_unit_2_price < 0 then raise exception 'Unit 2 price cannot be negative.'; end if;
  insert into public.shared_catalogue_products(name,price,image_url,unit_1_name,unit_1_price,unit_2_name,unit_2_price)
  values(trim(p_name),p_price,nullif(trim(p_image_url),''),nullif(trim(p_unit_1_name),''),p_unit_1_price,nullif(trim(p_unit_2_name),''),p_unit_2_price)
  returning id into v_id;
  return v_id;
end; $$;

create or replace function public.management_update_product_v2(
  p_password text, p_product_id uuid, p_name text, p_price numeric, p_image_url text default null,
  p_unit_1_name text default null, p_unit_1_price numeric default null,
  p_unit_2_name text default null, p_unit_2_price numeric default null
) returns boolean language plpgsql security definer set search_path = '' as $$
begin
  if not public.verify_management_password(p_password) then raise exception 'Incorrect management password.'; end if;
  if p_name is null or length(trim(p_name)) = 0 or length(trim(p_name)) > 160 then raise exception 'Enter a valid product name.'; end if;
  if p_price is null or p_price < 0 then raise exception 'Enter a valid main price.'; end if;
  if p_unit_1_price is not null and p_unit_1_price < 0 then raise exception 'Unit 1 price cannot be negative.'; end if;
  if p_unit_2_price is not null and p_unit_2_price < 0 then raise exception 'Unit 2 price cannot be negative.'; end if;
  update public.shared_catalogue_products
     set name=trim(p_name), price=p_price, image_url=nullif(trim(p_image_url),''),
         unit_1_name=nullif(trim(p_unit_1_name),''), unit_1_price=p_unit_1_price,
         unit_2_name=nullif(trim(p_unit_2_name),''), unit_2_price=p_unit_2_price
   where id=p_product_id;
  if not found then raise exception 'Product not found.'; end if;
  return true;
end; $$;

revoke all on function public.management_add_product_v2(text,text,numeric,text,text,numeric,text,numeric) from public;
revoke all on function public.management_update_product_v2(text,uuid,text,numeric,text,text,numeric,text,numeric) from public;
grant execute on function public.management_add_product_v2(text,text,numeric,text,text,numeric,text,numeric) to anon, authenticated;
grant execute on function public.management_update_product_v2(text,uuid,text,numeric,text,text,numeric,text,numeric) to anon, authenticated;

-- Shared notes: no management password is required to read or post.
create table if not exists public.shared_note_tags (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(trim(name)) between 1 and 40),
  created_at timestamptz not null default now()
);
create unique index if not exists shared_note_tags_name_ci on public.shared_note_tags (lower(name));

create table if not exists public.shared_notes (
  id uuid primary key default gen_random_uuid(),
  body text not null check (length(trim(body)) between 1 and 2000),
  author_name text not null check (length(trim(author_name)) between 1 and 40),
  created_at timestamptz not null default now()
);

alter table public.shared_note_tags enable row level security;
alter table public.shared_notes enable row level security;

drop policy if exists storesync_read_note_tags on public.shared_note_tags;
create policy storesync_read_note_tags on public.shared_note_tags for select to anon, authenticated using (true);
drop policy if exists storesync_add_note_tags on public.shared_note_tags;
create policy storesync_add_note_tags on public.shared_note_tags for insert to anon, authenticated with check (length(trim(name)) between 1 and 40);

drop policy if exists storesync_read_shared_notes on public.shared_notes;
create policy storesync_read_shared_notes on public.shared_notes for select to anon, authenticated using (true);
drop policy if exists storesync_add_shared_notes on public.shared_notes;
create policy storesync_add_shared_notes on public.shared_notes for insert to anon, authenticated with check (length(trim(body)) between 1 and 2000 and length(trim(author_name)) between 1 and 40);

grant select, insert on public.shared_note_tags to anon, authenticated;
grant select, insert on public.shared_notes to anon, authenticated;
revoke update, delete on public.shared_note_tags from anon, authenticated;
revoke update, delete on public.shared_notes from anon, authenticated;
