-- StoreSync public catalogue + shared management password.
-- Run once in Supabase SQL Editor. Existing Auth/store tables are left untouched.

create extension if not exists pgcrypto with schema extensions;

create table if not exists public.shared_catalogue_products (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(trim(name)) between 1 and 160),
  price numeric(12,2) not null check (price >= 0),
  image_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Carry forward any products already saved in the previous StoreSync products table.
-- Existing product IDs, names, prices and image paths are preserved; old tables are not deleted.
do $$
begin
  if to_regclass('public.products') is not null then
    insert into public.shared_catalogue_products(id, name, price, image_url, created_at, updated_at)
    select p.id, p.name, p.price, p.image_url, now(), coalesce(p.updated_at, now())
      from public.products p
    on conflict (id) do nothing;
  end if;
end $$;

create table if not exists public.store_management_settings (
  singleton boolean primary key default true check (singleton),
  password_hash text,
  updated_at timestamptz not null default now()
);
insert into public.store_management_settings(singleton, password_hash)
values (true, null) on conflict (singleton) do nothing;

alter table public.shared_catalogue_products enable row level security;
drop policy if exists "public_read_shared_catalogue" on public.shared_catalogue_products;
create policy "public_read_shared_catalogue" on public.shared_catalogue_products
for select to anon, authenticated using (true);
grant select on public.shared_catalogue_products to anon, authenticated;
revoke insert, update, delete on public.shared_catalogue_products from anon, authenticated;

alter table public.store_management_settings enable row level security;
revoke all on public.store_management_settings from anon, authenticated;

create or replace function public.management_password_is_set()
returns boolean language sql security definer set search_path = ''
as $$ select exists(select 1 from public.store_management_settings where singleton = true and password_hash is not null); $$;

create or replace function public.initialize_management_password(p_new_password text)
returns boolean language plpgsql security definer set search_path = ''
as $$
begin
  if p_new_password is null or length(p_new_password) < 8 then raise exception 'Password must be at least 8 characters.'; end if;
  update public.store_management_settings
     set password_hash = extensions.crypt(p_new_password, extensions.gen_salt('bf', 12)), updated_at = now()
   where singleton = true and password_hash is null;
  if not found then raise exception 'A management password already exists. Verify the current password to change it.'; end if;
  return true;
end; $$;

create or replace function public.verify_management_password(p_password text)
returns boolean language sql security definer set search_path = ''
as $$ select coalesce((select password_hash = extensions.crypt(p_password, password_hash) from public.store_management_settings where singleton = true and password_hash is not null), false); $$;

create or replace function public.change_management_password(p_current_password text, p_new_password text)
returns boolean language plpgsql security definer set search_path = ''
as $$
begin
  if p_new_password is null or length(p_new_password) < 8 then raise exception 'New password must be at least 8 characters.'; end if;
  update public.store_management_settings
     set password_hash = extensions.crypt(p_new_password, extensions.gen_salt('bf', 12)), updated_at = now()
   where singleton = true and password_hash = extensions.crypt(p_current_password, password_hash);
  if not found then raise exception 'Current password is incorrect.'; end if;
  return true;
end; $$;

create or replace function public.management_add_product(p_password text, p_name text, p_price numeric, p_image_url text default null)
returns uuid language plpgsql security definer set search_path = ''
as $$ declare v_id uuid; begin
  if not public.verify_management_password(p_password) then raise exception 'Incorrect management password.'; end if;
  if p_name is null or length(trim(p_name)) = 0 or length(trim(p_name)) > 160 then raise exception 'Enter a valid product name.'; end if;
  if p_price is null or p_price < 0 then raise exception 'Enter a valid non-negative price.'; end if;
  insert into public.shared_catalogue_products(name,price,image_url) values(trim(p_name),p_price,nullif(trim(p_image_url),'')) returning id into v_id;
  return v_id;
end; $$;

create or replace function public.management_update_product(p_password text, p_product_id uuid, p_name text, p_price numeric, p_image_url text default null)
returns boolean language plpgsql security definer set search_path = ''
as $$ begin
  if not public.verify_management_password(p_password) then raise exception 'Incorrect management password.'; end if;
  if p_name is null or length(trim(p_name)) = 0 or length(trim(p_name)) > 160 then raise exception 'Enter a valid product name.'; end if;
  if p_price is null or p_price < 0 then raise exception 'Enter a valid non-negative price.'; end if;
  update public.shared_catalogue_products set name=trim(p_name),price=p_price,image_url=nullif(trim(p_image_url),''),updated_at=now() where id=p_product_id;
  if not found then raise exception 'Product not found.'; end if;
  return true;
end; $$;

create or replace function public.management_delete_product(p_password text, p_product_id uuid)
returns boolean language plpgsql security definer set search_path = ''
as $$ begin
  if not public.verify_management_password(p_password) then raise exception 'Incorrect management password.'; end if;
  delete from public.shared_catalogue_products where id=p_product_id;
  if not found then raise exception 'Product not found.'; end if;
  return true;
end; $$;

revoke all on function public.management_password_is_set() from public;
revoke all on function public.initialize_management_password(text) from public;
revoke all on function public.verify_management_password(text) from public;
revoke all on function public.change_management_password(text,text) from public;
revoke all on function public.management_add_product(text,text,numeric,text) from public;
revoke all on function public.management_update_product(text,uuid,text,numeric,text) from public;
revoke all on function public.management_delete_product(text,uuid) from public;
grant execute on function public.management_password_is_set() to anon, authenticated;
grant execute on function public.initialize_management_password(text) to anon, authenticated;
grant execute on function public.verify_management_password(text) to anon, authenticated;
grant execute on function public.change_management_password(text,text) to anon, authenticated;
grant execute on function public.management_add_product(text,text,numeric,text) to anon, authenticated;
grant execute on function public.management_update_product(text,uuid,text,numeric,text) to anon, authenticated;
grant execute on function public.management_delete_product(text,uuid) to anon, authenticated;
