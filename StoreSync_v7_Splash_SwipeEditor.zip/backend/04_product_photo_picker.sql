-- StoreSync v4 photo picker support
-- Makes product photos publicly readable and permits anonymous image uploads.
-- Product records remain protected by the shared-password RPC functions.
-- Limit uploads to image formats and 5 MB.

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'product-images',
  'product-images',
  true,
  5242880,
  array['image/jpeg','image/png','image/webp','image/heic']
)
on conflict (id) do update
set public = true,
    file_size_limit = 5242880,
    allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "storesync_public_image_upload" on storage.objects;

create policy "storesync_public_image_upload"
on storage.objects
for insert
to anon, authenticated
with check (
  bucket_id = 'product-images'
  and (storage.foldername(name))[1] = 'catalogue'
  and name ~* '\\.(jpg|jpeg|png|webp|heic)$'
);

-- Public bucket objects can be fetched by their public URL.
-- No anonymous update or delete policy is granted.
